#include <stdio.h>

/**
* File              : vc_pt.c
* Author            : Hao-Tse,Shota
* Date              : Wed 6 Feb 2019
*/


void vc_pt(int *n)
{
  int a = 77;
  
  *n = a;
  printf("%i\n", *n);
}
