/**
* File              : vc_putstr.c
* Author            : Hao-Tse,Shota
* Date              : Wed 6 Feb 2019
*/
#include <stdio.h>

void vc_putstr(char *str)
{
    printf("%s\n", str);
}
    
