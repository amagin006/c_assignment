#include <stdio.h>

/**
* File              : vc_swap.c
* Author            : Hao-Tse,Shota
* Date              : Wed 6 Feb 2019
*/


void vc_swap(int *a, int *b)
{
	int temp = *a;
	*a = *b;
	*b = temp;


}

